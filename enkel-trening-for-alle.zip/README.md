# Enkel Trening for Alle

Dette er en enkel nettside med treningsprogrammer og skadeforebyggende øvelser.  
Siden er laget med **HTML**, **Tailwind CSS**, og **Lottie animations**.  

## Publisering
Denne siden kan publiseres med **GitHub Pages**:

1. Last opp mappen til et nytt repository på GitHub.
2. Gå til `Settings` → `Pages`.
3. Velg `main` branch og `/root` som kilde.
4. Lagre og vent et par minutter. Siden vil være live.

## Struktur
- `index.html` – hovedsiden
- `assets/` – bilder, animasjoner eller andre ressurser
