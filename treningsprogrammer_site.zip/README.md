# Treningsprogrammer & Skadeforebygging

Dette er en enkel nettside laget for GitHub Pages.

## Hvordan publisere

1. Last opp filene i dette repoet til GitHub.
2. Gå til **Settings → Pages** i repoet.
3. Velg branch `main` og root folder `/`.
4. Trykk **Save** og vent et minutt.
5. Nettsiden vil være tilgjengelig på `https://dittbrukernavn.github.io/treningsprogrammer/`
